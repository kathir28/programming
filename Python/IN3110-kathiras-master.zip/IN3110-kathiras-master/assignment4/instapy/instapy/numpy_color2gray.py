import cv2
import os
import timeit

import numpy as np
#from filecheck import file_check_exits


def file_check_exits(filename):
    """
    Checks if file exists on system
    :param:
    Filename : filname/path to image
    :rtype:
    True / false
    """
    if not os.path.exists(f'{filename}'):
        raise FileNotFoundError(f'The input filename, {filename}, does not exitst')


def numpy_color2gray(image_filename, outfile_name=None, scale=1):
    """
    :param
    image_filename: path to file
    outfile_name :name of file with applied filter
    scale : scale to resize picture
    :rtype: Array
    :return Picture with applied filter
    """
    file_check_exits(image_filename)
    image = cv2.imread(image_filename)
    image = cv2.resize(image, (0, 0), fx=float(scale), fy=float(scale))
    image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    weights = [0.07, 0.71, 0.21]
    grayscale = np.dot(image_rgb[:][:], weights)
    grayscale *= 255.0 / grayscale.max()
    grayscale = grayscale.astype(np.uint8)
    grayscale_bgr = cv2.cvtColor(grayscale, cv2.COLOR_RGB2BGR)
    if outfile_name is not None:
        cv2.imwrite(outfile_name, grayscale_bgr)

    return grayscale
