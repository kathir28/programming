import cv2
import os.path
import timeit
from numba import jit
#from filecheck import file_check_exits

def file_check_exits(filename):
    """
    Checks if file exists on system
    :param:
    Filename : filname/path to image
    :rtype:
    True / false
    """
    if not os.path.exists(f'{filename}'):
        raise FileNotFoundError(f'The input filename, {filename}, does not exitst')


@jit(nopython=True)
def numba_grayscale_filter(image):
    """
    :param image: Image
    :return image: Image with applied filter
    :rtype Array
    """
    weights = (0.07, 0.71, 0.21)
    for x in image:
        for z in x:
            z[:] = min(255, int(weights[0] * z[0] + weights[1] * z[1] + weights[2] * z[2]))
    return image


def numba_color2gray(image_filename, outfile_name=None, scale=1):
    """
    :param image_filename: path to file
    :param outfile_name :name of file with applied filter
    :param scale : scale to resize picture
    :rtype: Array
    :return Picture with applied filter
    """
    file_check_exits(image_filename)
    image = cv2.imread(image_filename)
    image = cv2.resize(image, (0, 0), fx=float(scale), fy=float(scale))
    image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

    grayscale = numba_grayscale_filter(image_rgb.astype("float64")).astype('uint8')
    grayscale_bgr = cv2.cvtColor(grayscale, cv2.COLOR_RGB2BGR)
    if outfile_name is not None:
        cv2.imwrite(outfile_name, grayscale_bgr)
    return grayscale
