import os.path


def file_check_exits(filename):
    """
    Checks if file exists on system
    :param:
    Filename : filname/path to image
    :rtype:
    True / false
    """
    if not os.path.exists(f'{filename}'):
        raise FileNotFoundError(f'The input filename, {filename}, does not exitst')
