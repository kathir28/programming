import cv2
import os
import timeit
from numba import jit
#from filecheck import file_check_exits

def file_check_exits(filename):
    """
    Checks if file exists on system
    :param:
    Filename : filname/path to image
    :rtype:
    True / false
    """
    if not os.path.exists(f'{filename}'):
        raise FileNotFoundError(f'The input filename, {filename}, does not exitst')


@jit(nopython=True)
def numba_sepia_filter(image):
    """
    :param image: image in array form
    :return image: image with applied filter
    :rtype: Array
    """
    sepia_matrix = [[0.393, 0.769, 0.189], [0.349, 0.686, 0.168], [0.272, 0.534, 0.131]]
    for x in image:
        for z in x:
            r = min(255, int(z[0] * sepia_matrix[0][0] + z[1] * sepia_matrix[0][1] + z[2] * sepia_matrix[0][2]))
            g = min(255, int(z[0] * sepia_matrix[1][0] + z[1] * sepia_matrix[1][1] + z[2] * sepia_matrix[1][2]))
            b = min(255, int(z[0] * sepia_matrix[2][0] + z[1] * sepia_matrix[2][1] + z[2] * sepia_matrix[2][0]))

            z[0] = r
            z[1] = g
            z[2] = b
    return image


def numba_color2sepia(image_filename, outfile_name=None, scale=1):
    """
    :param image_filename: path to file
    :param outfile_name :name of file with applied filter
    :param scale : scale to resize picture
    :rtype: Array
    :return Picture with applied filter
    """
    file_check_exits(image_filename)
    image = cv2.imread(image_filename)
    image = cv2.resize(image, (0, 0), fx=float(scale), fy=float(scale))
    image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

    image_sepia = numba_sepia_filter(image_rgb.astype("float64")).astype('uint8')
    image_sepia_bgr = cv2.cvtColor(image_sepia, cv2.COLOR_RGB2BGR)
    if outfile_name is not None:
        cv2.imwrite(outfile_name, image_sepia)

    return image_sepia
