from numpy_color2sepia import numpy_color2sepia

def sepia_image(image_filename, outfile_name = None):
    if outfile_name is not None:
        numpy_color2sepia(image_filename, outfile_name)
    else:
        numpy_color2sepia(image_filename)