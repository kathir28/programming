

import cv2
import os
import timeit
#from filecheck import file_check_exits

def file_check_exits(filename):
    """
    Checks if file exists on system
    :param:
    Filename : filname/path to image
    :rtype:
    True / false
    """
    if not os.path.exists(f'{filename}'):
        raise FileNotFoundError(f'The input filename, {filename}, does not exitst')


import numpy as np
def numpy_color2sepia(image_filename, outfile_name=None, scale=1):
    """
    :param image_filename: path to file
    :param outfile_name :name of file with applied filter
    :param scale : scale to resize picture
    :rtype: Array
    :return Picture with applied filter
    """
    file_check_exits(image_filename)
    image = cv2.imread(image_filename)
    image = cv2.resize(image, (0, 0), fx=float(scale), fy=float(scale))
    sepia_matrix = np.array([[0.272, 0.534, 0.131], [0.349, 0.686, 0.168],[0.393, 0.769, 0.189] ]) #bgr
    image_sepia = np.dot(image, sepia_matrix.T)
    image_sepia *= 255.0 / image_sepia.max()
    image_sepia = image_sepia.astype(np.uint8)
    if outfile_name is not None:
        cv2.imwrite(outfile_name, image_sepia)
    image_rgb = cv2.cvtColor(image_sepia, cv2.COLOR_BGR2RGB)
    return image_rgb

