import os.path

from numba_color2gray import numba_color2gray
from numba_color2sepia import numba_color2sepia
from numpy_color2gray import numpy_color2gray
from numpy_color2sepia import numpy_color2sepia
from python_color2gray import python_color2gray
from python_color2sepia import python_color2sepia

class filter():
    def __int__(self, method = 'numpy'):
        self.method = method

    @staticmethod
    def _file_check_exits(filename):
        if not os.path.exists(f'{filename}'):
            raise FileNotFoundError(f'The input filename, {filename}, does not exitst')

    def sepia_image(self, image_filename, outfile_name = None, scale= 1):
        filter._file_check_exits(image_filename)

        if self.method == 'numpy':
            return numpy_color2sepia(image_filename, outfile_name, scale)
        elif self.method == 'numba':
            return numba_color2sepia(image_filename, outfile_name, scale)
        elif self.method == 'python':
            return python_color2sepia(image_filename, outfile_name, scale)
        else:
            raise Exception('Please use one of these methods: numpy, numba or python')

    def grayscale_image(self, image_filename, outfile_name = None, scale= 1):
        filter._file_check_exits(image_filename)

        if self.method == 'numpy':
            return numpy_color2gray(image_filename, outfile_name, scale)
        elif self.method == 'numba':
            return numba_color2gray(image_filename, outfile_name, scale)
        elif self.method == 'python':
            return python_color2gray(image_filename, outfile_name, scale)
        else:
            raise Exception('Please use one of these methods: numpy, numba or python')
