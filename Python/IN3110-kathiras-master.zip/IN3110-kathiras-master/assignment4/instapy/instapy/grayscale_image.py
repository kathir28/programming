from numpy_color2gray import numpy_color2gray

def grayscale_image(image_filename, outfile_name = None):
    if outfile_name is not None:
        numpy_color2gray(image_filename, outfile_name)
    else:
        numpy_color2gray(image_filename)
