from instapy import numba_color2gray as numbagray
from instapy import numba_color2sepia as numbasepia
from instapy import numpy_color2gray as numpygray
from instapy import numpy_color2sepia as numpysepia
from instapy import python_color2gray as pythongray
from instapy import python_color2sepia as pythonsepia
import numpy as np
import cv2


def test_grayscale():
    test_image = np.random.randint(0, 255, (800, 900, 3))
    cv2.imwrite('test_image.jpg', test_image)
    g_image_python = cv2.cvtColor(pythongray.python_color2gray('test_image.jpg'), cv2.COLOR_RGB2BGR)
    g_image_numpy = cv2.cvtColor(numpygray.numpy_color2gray('test_image.jpg'), cv2.COLOR_RGB2BGR)
    g_image_numba = cv2.cvtColor(numbagray.numba_color2gray('test_image.jpg'), cv2.COLOR_RGB2BGR)

    assert (g_image_python[1][2][2] == g_image_numba[1][2][2])
    assert (test_image[:, :, :].shape == g_image_numba.shape)
    assert (test_image[:, :, :].shape == g_image_numpy.shape)


def test_sepia():
    test_image = np.random.randint(0, 255, (800, 900, 3))
    cv2.imwrite('test_image.jpg', test_image)
    s_image_python = cv2.cvtColor(pythonsepia.python_color2sepia('test_image.jpg'), cv2.COLOR_RGB2BGR)
    s_image_numpy = cv2.cvtColor(numpysepia.numpy_color2sepia('test_image.jpg'), cv2.COLOR_RGB2BGR)
    s_image_numba = cv2.cvtColor(numbasepia.numba_color2sepia('test_image.jpg'), cv2.COLOR_RGB2BGR)

    assert (s_image_python[1][2][2] == s_image_numba[1][2][2])
    assert test_image[:, :, :].shape == s_image_numba.shape
