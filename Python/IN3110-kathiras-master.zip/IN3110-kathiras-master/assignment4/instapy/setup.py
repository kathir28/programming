import setuptools

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setuptools.setup(
    name="instapy",
    version="0.0.1",
    author="Kathiravann Selathurai Pathmanathan",
    author_email="Kathiravann Sellathurai Pathmanathan",
    description="A filter class that applies filters on provided images",
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=setuptools.find_packages(),
    scripts=['bin/instapy'],
    url="https://github.uio.no/IN3110/IN3110-kathiras/tree/master/assignment4/instapy",

    classifiers=[
        "Programming Language :: Python :: 3",
    ],
    install_requires=["numpy", "numba", "opencv_python"],
    python_requires=">=3.6",
)