# Readme Assigment 4

Please make sure you have python3 istalled,. You can install this via choco package manager, see install instuctions here: https://chocolatey.org/install

Install python3 by using shell and entring : choco install python

After that you need to make sure you have pytest, numpy, numba, opencv_python installed. 

Install instructions :  Go into shell and enter: pip install {package_name}
Package intall: go into the root directory of the package and enter in shell "pip install ." This method will also install all dependencies



## Instapy

I have implemented an filter package which applies sepia and grayscalefilter on user-selected images. I wasn't sure if the assigment wanted me to use a class as well, so i have made a Filter class that incomporates all methods. 
The package can apply sepia filter and grayscale filter. It can also make a copy of the edited image on the machine and scale the images. 
The user can select between using python, numba or numpy to apply the filter.

## Methoeds/ Parameters

numba: uses numba to apply the selected filter on image

numpy :uses numpy to apply the selected filter on image

python: uses python to apply the selected filter on image

scale : scales down or up the images with the selected scale

outfile_name = The name of the image with filter, which is being saved



## Missing functonality
I have not tested the numpy implementation as thorough the numpy scales down all elements so max value is 255. Thus testing is difficult
The pytest seamingly only tests one statement, although there are more there


