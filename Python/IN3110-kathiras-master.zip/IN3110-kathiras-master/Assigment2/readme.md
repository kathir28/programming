Readme
Assigment 2
